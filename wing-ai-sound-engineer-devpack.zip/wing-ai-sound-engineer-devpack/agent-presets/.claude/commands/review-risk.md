# Review Risk

Review the pending mixer operation in the current context.

Return:

- risk level
- whether confirmation is required
- whether the target is unambiguous
- whether a safer observation exists
- exact confirmation phrase if needed
