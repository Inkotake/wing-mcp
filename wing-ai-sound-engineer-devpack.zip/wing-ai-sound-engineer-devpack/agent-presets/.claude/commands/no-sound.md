# No Sound Diagnosis

Start a structured no-sound diagnosis.

Arguments:
- `$ARGUMENTS`: target description, e.g. "主唱", "鼓手耳返", "直播吉他"

Workflow:

1. Resolve room and target.
2. Read room patch sheet.
3. Read WING status.
4. Use `wing_routing_trace` and `wing_meter_read`.
5. Classify breakpoint.
6. Ask one human action or prepare a safe fix.
7. Do not change phantom/routing/main/scene without exact confirmation.
