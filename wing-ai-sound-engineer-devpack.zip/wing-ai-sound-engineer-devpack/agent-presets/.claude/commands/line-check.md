# Line Check

Run a line-check workflow for the current room.

For each configured input:

1. Ask the human to play/speak.
2. Read input meter.
3. Confirm channel name/source.
4. Check mute/fader/main send only by reading.
5. Log pass/fail.

Do not perform write actions unless the user explicitly asks and confirms.
