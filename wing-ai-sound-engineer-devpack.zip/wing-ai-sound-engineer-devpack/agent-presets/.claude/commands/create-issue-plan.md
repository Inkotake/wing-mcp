# Create Issue Plan

Convert the requested feature into an implementation issue with:

- goal
- files/modules
- API/tool schema
- safety implications
- tests
- acceptance criteria
- hardware validation notes

All write-capable features must include safety tests.
