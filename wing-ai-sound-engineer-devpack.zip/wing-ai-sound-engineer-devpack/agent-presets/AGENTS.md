# Agent Development Guide

## Mission

Develop a production-grade AI sound engineer for Behringer WING family consoles.

## Work style

- Make small, testable changes.
- Write tests before real hardware behavior.
- Keep safety logic deterministic.
- Avoid clever prompts as safety enforcement.
- Prefer explicit schemas and finite-state workflows.

## Definition of done

A task is not complete unless:

- Code builds.
- Unit tests pass.
- Fake integration tests pass.
- Safety tests pass.
- Documentation updated.
- No raw unsafe write path introduced.
- Any untested hardware assumptions are clearly documented.

## Tool design

Good MCP tools are semantic:

```text
wing_channel_adjust_fader_prepare
wing_send_adjust_apply
wing_routing_trace
```

Bad MCP tools for normal use:

```text
send_raw_packet
set_any_param_without_policy
osc_write
```

Raw tools may exist only under developer mode and must be disabled by default.
