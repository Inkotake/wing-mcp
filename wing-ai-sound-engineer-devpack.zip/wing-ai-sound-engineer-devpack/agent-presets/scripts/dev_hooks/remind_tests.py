#!/usr/bin/env python3
import sys
print("Reminder: run unit, fake-wing integration, and safety tests before marking the issue done.", file=sys.stderr)
sys.exit(0)
