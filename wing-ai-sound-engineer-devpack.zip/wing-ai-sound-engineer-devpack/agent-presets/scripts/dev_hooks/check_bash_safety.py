#!/usr/bin/env python3
import sys
# Placeholder hook: in a real repo parse Claude Code hook JSON from stdin and block dangerous commands.
sys.exit(0)
