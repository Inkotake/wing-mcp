# WING AI Sound Engineer Dev Pack

这是给开发 Agent 使用的完整工程资料包，用于开发：

1. **wing-console-mcp**：完整可用的 Behringer WING / WING Compact / WING Rack MCP 控制服务。
2. **wing-console-operator Skill**：让 ChatGPT / Claude / 其他 Agent 安全地理解并调用调音台 MCP。
3. **AI 调音师系统**：放在排练室里，通过语音、知识库、记忆和 WING telemetry 辅助排查“为什么没声音”、耳返、反馈、路由、录音、直播等问题。

## 推荐架构

```text
voice/chat client
  -> ai-sound-engineer-agent-runtime
      -> wing-console-mcp
      -> sound-memory-mcp
      -> room-audio-mcp
      -> diagnosis-engine
  -> Behringer WING family console
```

## 包内容

```text
docs/                   产品、架构、协议、安全、诊断、语音、记忆、部署、测试文档
mcp-spec/               MCP 工具规范、风险策略、示例配置、schema
agent-presets/          CLAUDE.md、AGENTS.md、system prompt、子代理、slash commands、hooks
skill/                  wing-console-operator Skill 源码
skill-package/          单独打包好的 skill.zip，可用于上传 Skill
issues/                 可直接丢给开发 Agent 的任务卡
examples/               对话样例、Room A patch sheet、故障事件样例
src-stubs/              TypeScript / Rust 代码骨架片段，供 Agent 开始实现
reference-links/        官方资料与开源项目链接清单
```

## 立即给开发 Agent 的使用方式

1. 把 `agent-presets/CLAUDE.md` 复制到项目根目录。
2. 把 `agent-presets/.claude/` 复制到项目根目录。
3. 使用 `docs/00-executive-brief.md` 和 `docs/03-development-roadmap.md` 作为初始任务说明。
4. 从 `issues/ISSUE-001-monorepo-skeleton.md` 开始执行。
5. 所有真实硬件写操作必须经过 `prepare -> confirmation -> apply -> readback -> audit`。

## 重要安全原则

- 真实现场音频控制属于高风险操作。
- AI 不应直接拼接 raw OSC / Native 命令控制 WING。
- 所有写入必须由 MCP server 的安全层强制执行权限、风险、确认和审计。
- 默认 read-only / dry-run，尤其是排练或演出现场。
- Phantom power、routing、scene/snapshot/show recall、main mute、DCA mute、mute group、virtual soundcheck 必须显式确认。

## 资料时间戳

本包基于 2026-05-12 的公开资料调研整理。请在开始实机开发前再次核对 Behringer 官方下载页、WING Remote Protocols、MCP SDK、Claude Code/Agent SDK、OpenAI/DeepSeek API 文档的最新版本。
