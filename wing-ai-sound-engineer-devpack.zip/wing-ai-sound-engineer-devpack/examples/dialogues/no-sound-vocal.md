# Example Dialogue: Vocal No Sound

User: 为什么主唱没声音？

AI: 我先只检查，不会改调音台。主唱是 Vocal 1 吗？

User: 对。

AI tool plan:
- sound_room_get_patch_sheet(room-a)
- wing_channel_get(Vocal 1)
- wing_routing_trace(Vocal 1 -> Main LR)
- wing_meter_read([input, post-fader, main])

AI: 我看到 Vocal 1 通道没有 mute，fader 在 -6 dB，也送到 Main LR；但 Local 1 输入没有电平。请对着主唱话筒讲话三秒，我看输入 meter。

User speaks.

AI: 还是没有输入电平。问题大概率在话筒、线、输入口或 patch 之前。请先检查话筒线是否插在 WING Local 1；先不用动调音台。
