# Example Dialogue: Monitor Mix

User: 鼓手耳返里加一点主唱。

AI: 我先确认：鼓手耳返是 Bus 3，主唱是 Vocal 1。现在 Bus 3 里的 Vocal 1 send 是 -12 dB。我准备增加 2 dB 到 -10 dB。

AI asks confirmation if policy requires.

User: 确认把鼓手耳返里的主唱加 2dB。

AI applies and reads back.

AI: 已完成。Vocal 1 -> Drummer IEM 从 -12.0 dB 调到 -10.0 dB，WING 回读为 -10.0 dB。
