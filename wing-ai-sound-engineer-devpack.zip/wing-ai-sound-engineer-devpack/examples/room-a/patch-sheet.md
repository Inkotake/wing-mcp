# Room A Patch Sheet Example

| Channel | Name | Source | Notes |
|---:|---|---|---|
| 1 | Vocal 1 | LCL.1 | main vocal SM58 |
| 2 | Vocal 2 | LCL.2 | backing vocal |
| 3 | Guitar DI | LCL.3 | active DI, may need phantom only if confirmed |
| 4 | Bass DI | LCL.4 | passive DI, no phantom |
| 5 | Kick | LCL.5 | dynamic mic |
| 6 | Snare | LCL.6 | dynamic mic |
| 7 | OH L | LCL.7 | condenser, phantom required |
| 8 | OH R | LCL.8 | condenser, phantom required |

| Bus | Name | Owner | Notes |
|---:|---|---|---|
| 1 | Vocal IEM | singer | singer monitor |
| 2 | Guitar IEM | guitarist | guitar monitor |
| 3 | Drummer IEM | drummer | drummer monitor |
| 4 | Wedge 1 | shared | floor wedge |

Outputs:

- Main LR -> XLR 7/8 -> speaker processor -> powered speakers.
- Bus 3 -> XLR 3 -> drummer IEM transmitter.
