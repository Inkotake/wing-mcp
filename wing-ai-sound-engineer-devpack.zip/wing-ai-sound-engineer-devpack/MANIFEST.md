# Manifest

## Documentation

- `docs/00-executive-brief.md`：产品目标与总架构。
- `docs/01-product-research.md`：可用产品、库、官方资料调研。
- `docs/02-protocols-osc-native-wapi.md`：OSC / Native / wapi / libwing 区别与实现建议。
- `docs/03-development-roadmap.md`：完整开发阶段、验收标准和任务顺序。
- `docs/04-mcp-server-design.md`：MCP server 架构、transport、tools、resources、prompts。
- `docs/05-wing-tool-spec.md`：完整 WING MCP tool 设计。
- `docs/06-safety-policy.md`：风险分级、权限、确认、限幅、审计。
- `docs/07-diagnosis-engine.md`：AI 调音师诊断引擎和 no-sound 流程。
- `docs/08-memory-knowledge-rag.md`：知识库、房间记忆、事件记忆、RAG。
- `docs/09-voice-agent-design.md`：语音入口、TTS、VAD、Realtime、避免误触发。
- `docs/10-model-routing.md`：Claude / OpenAI / DeepSeek / local 模型路由策略。
- `docs/11-deployment.md`：本地 appliance、网络、安全部署。
- `docs/12-testing-and-hardware-validation.md`：fake-wing、仿真、实机测试矩阵。
- `docs/13-claude-code-like-runtime.md`：clean-room agent runtime 设计。
- `docs/14-skill-design.md`：wing-console-operator Skill 设计说明。
- `docs/15-known-risks-and-legal-notes.md`：泄露源码、第三方协议、现场安全等注意事项。

## Specs

- `mcp-spec/tools.yaml`：完整工具清单。
- `mcp-spec/risk-policy.json`：风险和确认策略。
- `mcp-spec/config.example.yaml`：MCP server 示例配置。
- `mcp-spec/canonical-paths.example.json`：canonical path 示例。
- `mcp-spec/schemas/*.schema.json`：关键 structured output schema。

## Agent presets

- `agent-presets/CLAUDE.md`：项目级 Claude Code / Agent SDK 指令。
- `agent-presets/AGENTS.md`：通用 coding agent 指令。
- `agent-presets/system-prompts/*.md`：AI 调音师 runtime prompts。
- `agent-presets/.claude/settings.json`：项目 hooks / permissions 示例。
- `agent-presets/.claude/agents/*.md`：专用 subagents。
- `agent-presets/.claude/commands/*.md`：slash command 模板。

## Skill

- `skill/wing-console-operator/`：Skill 源目录。
- `skill-package/skill.zip`：Skill 单独打包文件。

## Issues

- `issues/ISSUE-001-*.md` 到 `issues/ISSUE-018-*.md`：可直接交给开发 Agent 的任务卡。
