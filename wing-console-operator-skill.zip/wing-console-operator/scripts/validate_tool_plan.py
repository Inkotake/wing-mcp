#!/usr/bin/env python3
"""Validate a proposed WING MCP tool plan for obvious safety issues.

Usage:
  python validate_tool_plan.py plan.json

The script is intentionally conservative. It does not replace server-side PolicyEngine.
"""
import json
import sys
from pathlib import Path

CRITICAL_KEYWORDS = ["phantom", "routing", "scene", "snapshot", "show", "virtual_soundcheck", "raw"]
HIGH_KEYWORDS = ["main", "dca", "mute_group"]


def classify(tool: str) -> str:
    t = tool.lower()
    if any(k in t for k in CRITICAL_KEYWORDS):
        return "critical"
    if any(k in t for k in HIGH_KEYWORDS):
        return "high"
    if t.endswith("_apply") or "set" in t or "adjust" in t:
        return "medium"
    return "none"


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: validate_tool_plan.py plan.json", file=sys.stderr)
        return 2
    data = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    steps = data.get("steps", data if isinstance(data, list) else [])
    errors = []
    warnings = []
    has_read_before_write = False

    for i, step in enumerate(steps):
        tool = str(step.get("tool", ""))
        risk = classify(tool)
        if tool.endswith("_get") or "read" in tool or "trace" in tool or "status" in tool:
            has_read_before_write = True
        if risk in {"medium", "high", "critical"} and tool.endswith("_apply") and not has_read_before_write:
            errors.append(f"step {i}: write apply before any read/trace/status")
        if risk == "critical" and not step.get("confirmation_text"):
            errors.append(f"step {i}: critical tool {tool} lacks confirmation_text")
        if "raw" in tool.lower() and not data.get("developer_raw_enabled"):
            errors.append(f"step {i}: raw tool {tool} used without developer_raw_enabled")
        if risk == "high" and not step.get("confirmation_text"):
            warnings.append(f"step {i}: high-risk tool {tool} should include confirmation_text")

    result = {"ok": not errors, "errors": errors, "warnings": warnings}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
