# No-sound Troubleshooting

Signal chain:

source -> cable -> input/headamp -> source patch -> channel -> gate/dynamics -> mute/fader/DCA -> send/main -> bus/main/matrix -> output patch -> external processor/amp/speaker

Common breakpoints:

- No input meter: source/cable/input/patch/headamp/phantom/stagebox.
- Input meter present but post-fader absent: mute, fader, gate, insert, processing.
- Post-fader present but destination absent: send/main assignment, DCA, mute group, bus.
- Destination meter present but no room sound: output patch, processor, amp, speaker, cable.

Never enable phantom power automatically.
