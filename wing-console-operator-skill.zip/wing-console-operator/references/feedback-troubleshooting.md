# Feedback Troubleshooting

Start by identifying where feedback is heard.

Prefer low-risk steps:

- Reduce monitor send to offending wedge.
- Move microphone or speaker.
- Lower open unused mics.
- Check high-gain vocal channels.
- Use narrow EQ only when frequency evidence exists.

Do not make large EQ cuts or mute many channels without explaining impact.
