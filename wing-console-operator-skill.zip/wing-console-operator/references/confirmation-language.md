# Confirmation Language

Medium risk examples:

- "确认执行"
- "确认把主唱推高 3dB"

High risk requires object and action:

- "确认把 Main LR 降低 1dB"
- "确认 mute DCA 2"

Critical risk requires object, action, and risk acknowledgement:

- "确认开启 LCL.1 的 48V 幻象电源，我确认连接设备需要幻象电源"
- "确认 recall Scene 12，我知道这会改变当前调音台状态"
- "确认修改 Room A 的输出路由，我知道可能导致主扩或耳返无声"
