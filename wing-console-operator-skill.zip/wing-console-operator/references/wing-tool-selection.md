# WING Tool Selection

Use high-level tools first.

For channel level:
- `wing_param_resolve`
- `wing_channel_get`
- `wing_channel_adjust_fader_prepare`
- `wing_channel_adjust_fader_apply`

For monitor send:
- resolve performer/bus and source/channel
- `wing_send_get`
- `wing_send_adjust_prepare`
- `wing_send_adjust_apply`

For no sound:
- `sound_diagnosis_start`
- `sound_room_get_patch_sheet`
- `wing_routing_trace`
- `wing_meter_read`
- `wing_signal_check`

For raw protocol:
- Refuse unless developer mode is explicitly enabled.
- Use raw prepare/apply only in maintenance/developer profile.
