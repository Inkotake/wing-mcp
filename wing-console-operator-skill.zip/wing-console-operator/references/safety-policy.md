# Safety Policy

- Always diagnose before changing.
- All writes must be prepare/apply/readback/audit.
- Medium risk normally requires confirmation in live/rehearsal mode.
- High and critical risk always require explicit confirmation.
- Critical operations include phantom power, routing, scene/snapshot/show recall, virtual soundcheck routing, network/global preferences, and raw protocol commands.
- Main LR, DCA mute, mute groups, and large fader jumps are high risk.
- Never treat vague phrases like "ok" or "do it" as confirmation for critical actions.
- If a safer read-only diagnostic step exists, do it first.
