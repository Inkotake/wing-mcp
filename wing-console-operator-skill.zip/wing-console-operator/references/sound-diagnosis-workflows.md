# Sound Diagnosis Workflows

## No sound

1. Determine scope: channel, monitor, main, recording, livestream.
2. Resolve target from room memory and WING names.
3. Read channel/source/routing.
4. Read meters at input, post-fader, destination.
5. Classify breakpoint.
6. Ask one human action or prepare a fix.

## Feedback

1. Ask where feedback is heard: main, wedge, IEM, livestream.
2. Read active mics and monitor sends.
3. Check recent fader/send/EQ changes.
4. If audio analysis is available, identify peak frequency.
5. Prefer reducing offending send or moving mic/speaker before drastic EQ.

## Monitor issue

1. Identify performer and bus.
2. Identify source to add/remove.
3. Read current send level and bus master.
4. Adjust small delta with confirmation if required.
