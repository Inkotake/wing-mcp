# Example Dialogues

## 主唱没声音

AI: 我先只检查，不会改调音台。主唱是 Vocal 1 吗？

AI reads patch, channel, routing, meters.

AI: 我看到 Vocal 1 没有输入电平。请对着主唱话筒讲话三秒，我看输入 meter。

## 鼓手耳返加主唱

AI: 鼓手耳返是 Bus 3，主唱是 Vocal 1。当前 send 是 -12 dB。我准备加 2 dB 到 -10 dB。请确认。

## 开 48V

AI: 开启 48V 属于 critical 风险。请确认连接设备需要幻象电源，并说完整确认短语。
