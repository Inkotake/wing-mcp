# Monitor Mix Workflows

When user asks to adjust monitor mix:

1. Resolve performer to bus.
2. Resolve source to channel.
3. Read current send and bus master.
4. Prefer small deltas: +1 to +3 dB.
5. Apply with confirmation if policy requires.
6. Read back.

Example:

"鼓手耳返加主唱" -> Vocal 1 send to Drummer IEM +2 dB.
