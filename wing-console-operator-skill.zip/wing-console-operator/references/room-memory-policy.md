# Room Memory Policy

Use room memory for patch sheets, channel aliases, bus ownership, speaker outputs, mic inventory, and historical incidents.

Do not trust memory over live telemetry.

Write memory only when:

- user confirmed it,
- tool observed it,
- document source supports it,
- or it is marked as inference requiring review.

Safety memory is admin-only.
